function navbar(){
    return ` <div id="navbar">
    <div>
      <h3> <a href="/">Home</a> </h3>
    </div>
   
    <div class="options">
      <h3><a href="name.html">Name</a></h3>
      <h3><a href="day.html">Day</a></h3>
      <h3><a href="randam.html">Random</a></h3>
     

    </div>
  </div>`;
}

export default navbar;

